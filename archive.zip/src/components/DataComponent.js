import React from 'react';
import { Col, Row} from 'react-bootstrap';
const thStyle = {
  fontFamily: "Anton",
  fontWeight: "normal",
  fontStyle: "normal"
};

class DataComponent extends React.Component {

  render() {
    return (
      <div style={{ padding: '50px' }}>
        <Row>
          <Col></Col>
          <Col style={{ fontSize: '30' }}>
            <u>   Директору ООО "Строй-06"<br></br> Джумулдаевой Петимат Абдуловне <br></br>
              {this.props.data.last_name} {this.props.data.first_name} {this.props.data.fathers_name}<br></br>
              {this.props.data.adress1}
            </u>
          </Col>
        </Row>
        <Row >
          <div style={{ margin: '30px', display: 'flex', justifyContent: 'center' }}>
            <h3> Заявление </h3>
          </div>
        </Row>
        <Row>
          Прошу Вас выдать мне ипотечный займ для приобретения недвижимости по следующим параметрам:
        </Row>

        <table style={thStyle} className="table">
          <thead>
            {/* <tr>
                {/* <th>Product A</th>
                <th>Product B</th>
              </tr> */}
          </thead>
          <tbody>
            <tr>
              <th>Тип недвижимости</th>
              <th>{this.props.data.property_type}</th>
            </tr>
            <tr>
              <th>Кадастровый номер объекта недвижимости, планируемого к приобретению</th>
              <th>{this.props.data.property_number1}</th>
            </tr>
            <tr>
              <th>Сумма займа</th>
              <th>{this.props.data.amount} руб.</th>
            </tr>
          </tbody>
        </table>
        <Row >
          С общими усовиями предоставления займов ознакомлен, в том числе, проинформирован о возможности реструктуризации долга;
          мне также известно, что за предоставление недостоверных сведений  с целью получения указанного займа  я несу уголовную ответственность.
          В связи с чем, я даю свое полное согласие на проверку предоставленных мной документов.
        </Row>
        <Row>

          <Col style={{ display: 'flex', justifyContent: 'center' }}>{this.props.data.date}</Col>
          <Col style={{ display: 'flex', justifyContent: 'center' }}>____________________________</Col>

        </Row>
      </div>
    );
  }
}
export default DataComponent;
// {this.props.data.first_name}
// {this.props.data.last_name}
// {this.props.data.fathers_name}
// 
// {this.props.data.borne_date}
// {this.props.data.passport_series}
// {this.props.data.passport_number}
// {this.props.data.date_issue}
// 
// {this.props.data.property_number1}
// {this.props.data.property_number2}
// {this.props.data.amount}
// {this.props.data.adress2}
// 
