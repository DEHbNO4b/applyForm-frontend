import { Card } from "react-bootstrap"

function AboutUs() {
    return (
        <Card border="info" style={{margin:'5px'}}>
            <Card.Body>
                Мы долго шли к успеху. Первый офис нашей компании был в Годдарте.
                    Успех пришел к нам не сразу, а через годы тяжелого фарма в долине Драконов
                     и бесчисленных сражений в Варке.
            </Card.Body>
        </Card>
    )
} export default AboutUs