import { Card } from "react-bootstrap"

function Footer() {
    return (
        <Card className="text-center" bg="" border="info" variant="light">
        <Card.Body>IBRAHIMcorporation 2006-2023</Card.Body>
            
        </Card>
    )
}
export default Footer