
import { Card } from "react-bootstrap"

function Home() {
    
    return (
        <Card style={{ margin: '5px',}}>
            <Card.Header>HOME</Card.Header>
        </Card>
    )
}
export default Home